package Equipiada.Templates.IEnquirer;

public interface IEnquirer {
    public void startInterview();
}
