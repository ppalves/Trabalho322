package Equipiada.Templates.IDataSource;

public interface IDataSource {
    String getDataSource();
    void setDataSource(String dataSource);
}