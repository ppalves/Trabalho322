package Equipiada.Templates.IResponderReceptacle;

import Equipiada.Templates.IResponder.IResponder;

public interface IResponderReceptacle {
    public void connect(IResponder responder);
}