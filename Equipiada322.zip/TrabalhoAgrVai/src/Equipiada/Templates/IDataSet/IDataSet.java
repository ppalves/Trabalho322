package Equipiada.Templates.IDataSet;

import Equipiada.Templates.IDataSource.IDataSource;
import Equipiada.Templates.ITableProducer.ITableProducer;

public interface IDataSet extends IDataSource, ITableProducer {
}