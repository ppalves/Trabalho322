package Equipiada.Templates.ITableProducer;

public interface ITableProducer {
    String[] requestAttributes();
    String[][] requestInstances();
}