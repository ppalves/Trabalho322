package Equipiada.Templates.ITableProducerReceptacle;

import Equipiada.Templates.ITableProducer.ITableProducer;

public interface ITableProducerReceptacle {
    public void connect(ITableProducer producer);
}