package Equipiada.Components.PCA_Analysis.IPCA_Analysis;
import java.io.IOException;

public interface IPCA_Analysis {
	public void pca ();
	public void showPlot() throws IOException;
}

