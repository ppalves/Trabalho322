#!/bin/bash

echo Instalacao dos modulos de Python3

python3 -m pip install pandas
python3 -m pip install matplotlib
python3 -m pip install numpy
python3 -m pip install sklearn

echo seu pythonPATH:
which python3



